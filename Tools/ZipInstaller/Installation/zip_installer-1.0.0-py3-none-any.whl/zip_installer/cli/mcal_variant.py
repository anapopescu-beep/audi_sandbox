from ..eb_utils.eb_plugin_xml import EbPluginXML
import sys
import getopt

def _usage():
    print("Turn on/off the EB MCAL variant setting")
    print("mcal_variant [on|off] [-h|-help]")
    print("   --on  : turn on the MCAL variant")
    print("   --off : turn off the MCAL variant")
    sys.exit(2)

def _get_file_list():
    file_list = {
        'Adc': 'S:/Tools/EB_BSW_8.5.1/Workspace/plugins/Adc_TS_T40D2M10I1R0/plugin.xml',
        'Can': 'S:/Tools/EB_BSW_8.5.1/Workspace/plugins/Can_TS_T40D2M10I1R0/plugin.xml',
        'Dio': '',
        'Fee': '',
        'Fls': 'S:/Tools/EB_BSW_8.5.1/Workspace/plugins/Fls_TS_T40D2M10I1R0/plugin.xml',
        'Mcu': 'S:/Tools/EB_BSW_8.5.1/Workspace/plugins/Mcu_TS_T40D2M10I1R0/plugin.xml',
        'Port': 'S:/Tools/EB_BSW_8.5.1/Workspace/plugins/Port_TS_T40D2M10I1R0/plugin.xml',
        'Pwm': 'S:/Tools/EB_BSW_8.5.1/Workspace/plugins/Pwm_TS_T40D2M10I1R0/plugin.xml',
        'Spi': 'S:/Tools/EB_BSW_8.5.1/Workspace/plugins/Spi_TS_T40D2M10I1R0/plugin.xml',
    }
    return file_list


def mcal_variant_cli():
    try:
        opts, _ = getopt.getopt(sys.argv[1:], "", ["help", "on", "off"])
    except getopt.GetoptError as err:
        # print help information and exit:
        print(str(err))  # will print something like "option -a not recognized"
        _usage()
    
    option = None
    for o, _ in opts:
        if o == "--on":
            option = "on"
        elif o == "--off":
            option = "off"
        elif o in ("-h", "--help"):
            _usage()
        else:
            assert False, "unhandled option"

    if (option == None):
        _usage()

    plugin = EbPluginXML()
    
    file_list = _get_file_list()

    for module in sorted(file_list):
        file_name = file_list[module]
        if (file_name == ""):
            continue
        print("Processing %s ..." % module)
        if (option == "on"):
            plugin.turn_on_mcal_variant(file_name)
        elif (option == "off"):
            plugin.turn_off_mcal_variant(file_name)
        

if __name__ == "__main__":
    mcal_variant_cli()