from ..eb_utils.eb_xdm import EbXdm
import sys
import getopt

def _usage():
    print("Add the VDA calibration setting")
    print("vda_cali [-h|--help]")
    print("   -h     : Show this information")
    print("   --help : Show this information")
    sys.exit(2)

def vda_cali_cli():
    try:
        opts, _ = getopt.getopt(sys.argv[1:], "c", ["help", "on", "off"])
    except getopt.GetoptError as err:
        print(str(err))  
        _usage()
    
    for o, _ in opts:
        if o in ("-h", "--help"):
            _usage()
        else:
            assert False, "unhandled option"

    ebXdm = EbXdm()
    ebXdm.read_xdm("S:/Tools/Tresos_Configuration_8.5.1/Workspace/PP4G_Extended/config/Can.xdm")
        

if __name__ == "__main__":
    vda_cali_cli()