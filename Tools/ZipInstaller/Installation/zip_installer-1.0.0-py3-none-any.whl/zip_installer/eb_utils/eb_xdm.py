from .models.eb_models import EBControl, EBVariable
import xml.etree.ElementTree as ET
import sys

class EbXdm(object):
    def _create_element(self):
        control = EBControl()
        control.name = "HOR_083_FrTrAsdmPassSafeCANFr02"
        control.type = "IDENTIFIABLE"

        var = EBVariable()
        var.name = "CanFdPaddingValue"
        var.type = "INTEGER"
        var.value = "0"

        control.addEBVariable(var)

        return control

    def get_namespaces(self):
        namespaces = {
            '': 'http://www.tresos.de/_projects/DataModel2/14/root.xsd',
            'a': 'http://www.tresos.de/_projects/DataModel2/14/attribute.xsd',
            'v': 'http://www.tresos.de/_projects/DataModel2/06/schema.xsd',
            'd': 'http://www.tresos.de/_projects/DataModel2/06/data.xsd',
            'variant': 'http://www.tresos.de/_projects/DataModel2/11/variant.xsd',
        }
        return namespaces

    def get_inner_namespace(self):
        namespaces = {
            'ad': 'http://www.tresos.de/_projects/DataModel2/08/admindata.xsd',
            'cd': 'http://www.tresos.de/_projects/DataModel2/08/customdata.xsd',
            'f': 'http://www.tresos.de/_projects/DataModel2/14/formulaexpr.xsd',
            'icc': 'http://www.tresos.de/_projects/DataModel2/08/implconfigclass.xsd',
            'mt': 'http://www.tresos.de/_projects/DataModel2/11/multitest.xsd',
            'variant': 'http://www.tresos.de/_projects/DataModel2/11/variant.xsd',
        }
        return namespaces

    def read_xdm(self, file_name):
        namespaces = self.get_namespaces()
        for prefix, uri in namespaces.items():
            if (prefix == "variant"):
                continue
            ET.register_namespace(prefix, uri)

        tree = ET.parse(file_name)
        root = tree.getroot()
        #for lst in root.findall(".//d:lst[@name='CanHardwareObject']/d:ctr", namespaces):
        #    print(lst.get('name'))
        canHardwareObject = root.find(".//d:lst[@name='CanHardwareObject']", namespaces) 
        canHardwareObject.append(self._create_element().toXml())

        #namespaces = self.get_namespaces()

        #for key, value in namespaces.items():
        #    etree.register_namespace(key, value)

        tree.write(file_name, xml_declaration=True)

    def format_xdm(self, file_name):
        namespaces = self.get_namespaces()
        for prefix, uri in namespaces.items():
            if (prefix == "variant"):
                continue
            ET.register_namespace(prefix, uri)

        tree = ET.parse(file_name)
        root = tree.getroot()
        autosarNode = root.find(".//d:ctr[@factory='autosar']", namespaces)
        for prefix, uri in self.get_inner_namespace().items():
            autosarNode.set('xmlns:' + prefix, uri)
        tree.write(file_name, xml_declaration=True, encoding=None)
