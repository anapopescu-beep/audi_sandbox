from string import Template

class Templatelternative(Template):
    delimiter = '#'