import getopt
import sys
import os
from shutil import copyfile

def _usage():
    print("Create the default folder structure")
    print("alvfolder [-t|--tool] [-c|--component] [-u|--unittest] [-h|-help]")
    print("   -t|--tool      : default folder for tools")
    print("   -c|--component : default folder for components")
    sys.exit(2)

def _create_tools_default_folder():
    os.makedirs('Config', exist_ok=True)
    os.makedirs('Installation', exist_ok=True)
    os.makedirs('Workspace', exist_ok=True)

def _create_component_default_folder():
    os.makedirs('Config', exist_ok=True)
    os.makedirs('Design', exist_ok=True)
    os.makedirs('Tests', exist_ok=True)

def create():
    try:
        opts, _ = getopt.getopt(sys.argv[1:], "htc", ["help" "tool", "component"])
    except getopt.GetoptError as err:
        # print help information and exit:
        print(str(err))  # will print something like "option -a not recognized"
        _usage()
    
    option = None
    for o, _ in opts:
        if o in ("-t", "--tool"):
            option = "tool"
        elif o in ("-c", "--component"):
            option = "component"
        elif o in ("-h", "--help"):
            _usage()
        else:
            assert False, "unhandled option"

    if (option == "component"):
        _create_component_default_folder()
    elif (option == "tool"):
        _create_tools_default_folder()
    else:
        _usage()

if __name__ == "__main__":
    create()
