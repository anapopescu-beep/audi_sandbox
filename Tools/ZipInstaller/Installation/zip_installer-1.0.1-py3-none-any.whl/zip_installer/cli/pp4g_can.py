import getopt, sys
import xlrd

def _usage():
    print("Adjust the CAN signal with CIL name")
    print("pp4g_can [-m] [--source arg] [--xls arg] [-h|-help]")
    print("   --source arg : the name of the c source file")
    print("   --xls arg    : the name of the mapping excel file")
    sys.exit(2)

def read(self, excel_name): # type: Dict(str)
    result = {}
    try:
        with xlrd.open_workbook(excel_name, formatting_info = True) as book:
            sheet = book.sheet_by_index(0)

            if (sheet == None):
                raise ValueError("Sheet <%s> can not be found.")
    except Exception as err:
        print(err)
        raise err

def pp4g_can_signal_replace(source: str, excel: str):
    results = []
    with open(source) as f_in:
        content = f_in.readlines()

        for line in content:
            m = re.match(r'^.*(Rte_Write_psr_(u8|s8|u16|s16|u32|s32)\w+)', line)
            if (m != None):
                variable = Variable() 
                variable.name = m.group(1)
                variable.type = convert_data_type(m.group(2))
                functionality.add_variable(variable)

    writer = MockupXmlWriter()
    writer.write(xml_file, functionality)

def pp4g_can_cli():
    try:
        opts, _ = getopt.getopt(sys.argv[1:], "h", ["help", "xls=", "source="])
    except getopt.GetoptError as err:
        # print help information and exit:
        print(str(err))  # will print something like "option -a not recognized"
        _usage()
    
    excel = None
    source   = None
    action = "Replace"
    for o, arg in opts:
        if o in ("--xls"):
            excel = arg
        elif o in ("--source"):
            source = arg
        elif o in ("-h", "--help"):
            _usage()
        else:
            assert False, "unhandled option"

    if (action == None):
        _usage()

    if (action == "Replace"):
        if (excel == None):
            print("Please enter the excel name")
        elif (source == None):
            print("Please enter the xml name")
        else:
            pp4g_can_signal_replace(source, excel)

if __name__ == "__main__":
    pp4g_can_cli()