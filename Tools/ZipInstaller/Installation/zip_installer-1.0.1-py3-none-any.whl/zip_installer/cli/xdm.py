from ..eb_utils.eb_xdm import EbXdm
import sys
import getopt

def _usage():
    print("Format the xdm File")
    print("xdm_format [-h|--help] xdm_file")
    print("   -h       : Show this information")
    print("   --help   : Show this information")
    print("   xdm_file : The name of the xdm file")
    sys.exit(2)

def xdm_format_cli():
    if (len(sys.argv) < 2):
        _usage()

    ebXdm = EbXdm()
    ebXdm.format_xdm("S:/Tools/Tresos_Configuration_8.5.1/Workspace/PP4G_Extended/config/Can.xdm")
        

if __name__ == "__main__":
    xdm_format_cli()