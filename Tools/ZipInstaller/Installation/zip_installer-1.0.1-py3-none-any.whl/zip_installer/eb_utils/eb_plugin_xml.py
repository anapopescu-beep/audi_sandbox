import re

class EbPluginXML(object):
    def read_all_lines(self, file_name):
        with open(file_name, 'r') as f_in:
            lines = f_in.readlines() 
            return lines

    def change_variant_aware(self, file_name, lines, value):
        expr = r'.*"variantAware"\s+value="(true|false).*"'
        with open(file_name, 'w') as f_out:
            for line in lines:
                result = re.match(expr, line)
                if (result):
                    print("update <%s>: change variantAware from <%s> to <%s>" % (file_name, result.group(1), value))
                    f_out.write(line.replace(result.group(1), value))
                else:
                    f_out.write(line)

    def turn_on_mcal_variant(self, file_name): #type (self, str) -> None
        try:
            lines = self.read_all_lines(file_name)
            self.change_variant_aware(file_name, lines, 'true')
        except IOError as e:
            print(str(e))

    def turn_off_mcal_variant(self, file_name):
        try:
            lines = self.read_all_lines(file_name)
            self.change_variant_aware(file_name, lines, 'false')
        except IOError as e:
            print(str(e))
        