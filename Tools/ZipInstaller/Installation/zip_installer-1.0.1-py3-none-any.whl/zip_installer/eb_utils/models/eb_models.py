import xml.etree.ElementTree as etree

class EBControl(object):
    def __init__(self):
        self.name = ""
        self.type = ""
        self.variant_list = []

    @property
    def name(self) -> str:
        return self._name

    @name.setter
    def name(self, name):
        self._name = name

    @property
    def type(self) -> str:
        return self._type

    @type.setter
    def type(self, type):
        self._type = type

    def addEBVariable(self, variable):
        self.variant_list.append(variable)

    def toXml(self):
        element = etree.Element('d:var')
        element.set('name', self.name)
        element.set('type', self.type)

        return element

class EBVariable(object):
    def __init__(self):
        self._name = ""
        self._type = ""
        self._value = ""

    @property
    def name(self) -> str:
        return self._name

    @name.setter
    def name(self, name):
        self._name = name

    @property
    def type(self) -> str:
        return self._type

    @type.setter
    def type(self, type):
        self._type = type

    @property
    def value(self) -> str:
        return self._value

    @value.setter
    def value(self, value):
        self._value = value

class EBAttribute:
    def __init__(self):
        self._name = ""
        self._type = ""
        self._value = ""
        self._variant = None

    @property
    def name(self) -> str:
        return self._name

    @name.setter
    def name(self, name):
        self._name = name

    @property
    def type(self) -> str:
        return self._type

    @type.setter
    def type(self, type):
        self._type = type

    @property
    def value(self) -> str:
        return self._value

    @value.setter
    def value(self, value):
        self._value = value

class EBVariant:
    def __init__(self):
        self._criterion = ""
        self._expr = ""

    @property
    def criterion(self) -> str:
        return self._criterion

    @criterion.setter
    def criterion(self, criterion):
        self._criterion = criterion

    @property
    def expr(self) -> str:
        return self._expr

    @expr.setter
    def expr(self, expr):
        self._expr = expr